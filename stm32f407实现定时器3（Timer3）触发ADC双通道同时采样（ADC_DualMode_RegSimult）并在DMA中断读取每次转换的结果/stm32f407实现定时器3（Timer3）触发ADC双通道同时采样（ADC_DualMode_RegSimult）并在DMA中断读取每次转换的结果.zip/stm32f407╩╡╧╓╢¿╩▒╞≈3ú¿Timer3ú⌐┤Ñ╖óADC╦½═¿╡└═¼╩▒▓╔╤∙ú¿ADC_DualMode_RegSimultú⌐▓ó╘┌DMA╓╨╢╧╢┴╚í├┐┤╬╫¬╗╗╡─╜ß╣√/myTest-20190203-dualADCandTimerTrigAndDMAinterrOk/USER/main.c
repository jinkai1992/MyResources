#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "stdio.h"
#include "string.h"


char msgstr[64];
unsigned int adcVal,adcVal01,adcVal02;
__IO uint16_t aADCDualConvertedValue[2];


void TIM3_Int_Init(u16 arr,u16 psc);		   
void Adc_Init(void);
static void DMA_Config(void);


int main(void)
{ 
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//����ϵͳ�ж����ȼ�����2
	delay_init(168);  //��ʼ����ʱ����
	uart_init(115200);
 	TIM3_Int_Init(5000-1,8400-1);	//��ʱ��ʱ��84M����Ƶϵ��8400������84M/8400=10Khz�ļ���Ƶ�ʣ�����5000��Ϊ500ms    
 	//TIM3_Int_Init(1000-1,72-1);	//��ʱ��ʱ��84M����Ƶϵ��8400������84M/8400=10Khz�ļ���Ƶ�ʣ�����5000��Ϊ500ms    
	
	
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);//ʹ��GPIOAʱ��
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE); //ʹ��ADC1ʱ��
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC2, ENABLE); //ʹ��ADC1ʱ��
	
	Adc_Init();
	DMA_Config();

	ADC_RegularChannelConfig(ADC1, 5, 1, ADC_SampleTime_15Cycles );	//ADC1,ADCͨ��,480������,��߲���ʱ�������߾�ȷ��		
	ADC_RegularChannelConfig(ADC2, 6, 1, ADC_SampleTime_15Cycles );	//ADC1,ADCͨ��,480������,��߲���ʱ�������߾�ȷ��			    
	 
	while(1)
	{
		delay_ms(500);//��ʱ200ms
		printf("While Run...\r\n");
		
		  
//		ADC_SoftwareStartConv(ADC1);		//ʹ��ָ����ADC1������ת����������
//		while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC ));//�ȴ�ת������
//		adcVal= ADC_GetConversionValue(ADC1);	//�������һ��ADC1�������ת�����			
//		sprintf(msgstr,"While adc=%d.\r\n",adcVal);
//		printf(msgstr);
		
//		adcVal01= aADCDualConvertedValue[0];			
//		adcVal02= aADCDualConvertedValue[1];		
//		sprintf(msgstr,"adc ch5=%d ch6=%d\r\n",adcVal01,adcVal02);
//		printf(msgstr);
		
		printf("\r\n");
	};
}

//��ʱ��3�жϷ�����
void TIM3_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM3,TIM_IT_Update)==SET) //����ж�
	{
		printf("Timer3 Run.\r\n");
		
//		ADC_SoftwareStartConv(ADC1);
//		adcVal= ADC_GetConversionValue(ADC1);	//�������һ��ADC1�������ת�����			
//		sprintf(msgstr,"timer adc=%d.\r\n",adcVal);
//		printf(msgstr);
		
				
//		ADC_SoftwareStartConv(ADC1);
//		//while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC ));
//		adcVal01= aADCDualConvertedValue[0];			
//		adcVal02= aADCDualConvertedValue[1];		
//		sprintf(msgstr,"adc ch5=%d ch6=%d\r\n",adcVal01,adcVal02);
//		printf(msgstr);
		
//		printf("......");
	
//		adcVal01= aADCDualConvertedValue[0];			
//		adcVal02= aADCDualConvertedValue[1];		
//		sprintf(msgstr,"adc ch5=%d ch6=%d\r\n",adcVal01,adcVal02);
//		printf(msgstr);

		printf("\r\n");
	}
	TIM_ClearITPendingBit(TIM3,TIM_IT_Update);  //����жϱ�־λ
}

//https://blog.csdn.net/u014124220/article/details/50785775
//https://blog.csdn.net/liuyi1207164339/article/details/46993553
//https://blog.csdn.net/xu1129005165/article/details/73468559
void TIM3_Int_Init(u16 arr,u16 psc)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_OCInitTypeDef         TIM_OCInitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);  ///ʹ��TIM3ʱ��
	
  TIM_TimeBaseInitStructure.TIM_Period = arr; 	//�Զ���װ��ֵ
	TIM_TimeBaseInitStructure.TIM_Prescaler=psc;  //��ʱ����Ƶ
	TIM_TimeBaseInitStructure.TIM_CounterMode=TIM_CounterMode_Up; //���ϼ���ģʽ
	TIM_TimeBaseInitStructure.TIM_ClockDivision=TIM_CKD_DIV1; 
	
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStructure);//��ʼ��TIM3
	
//	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE); //������ʱ��3�����ж�
	
	
	//*****************************************//
	 /* TIM1 channel1 configuration in PWM mode */ 
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; 
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;                
	TIM_OCInitStructure.TIM_Pulse = 500; 
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;         
	TIM_OC1Init(TIM3, &TIM_OCInitStructure); 
	TIM_CtrlPWMOutputs(TIM3, ENABLE);

	
	TIM_Cmd(TIM3,ENABLE); //ʹ�ܶ�ʱ��3
	
	NVIC_InitStructure.NVIC_IRQChannel=TIM3_IRQn; //��ʱ��3�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0x01; //��ռ���ȼ�1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=0x03; //�����ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
}

													   
void  Adc_Init(void)
{    
  GPIO_InitTypeDef  GPIO_InitStructure;
	ADC_CommonInitTypeDef ADC_CommonInitStructure;
	ADC_InitTypeDef       ADC_InitStructure;
	

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5|GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
 
	RCC_APB2PeriphResetCmd(RCC_APB2Periph_ADC1,ENABLE);	  //reset adc
	RCC_APB2PeriphResetCmd(RCC_APB2Periph_ADC1,DISABLE);	//end reset adc
 
	
  ADC_CommonInitStructure.ADC_Mode = ADC_DualMode_RegSimult;
  ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
  ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_1; 
  ADC_CommonInitStructure.ADC_Prescaler = ADC_Prescaler_Div4;//Ԥ��Ƶ4��Ƶ��ADCCLK=PCLK2/4=84/4=21Mhz,ADCʱ����ò�Ҫ����36Mhz 
  ADC_CommonInit(&ADC_CommonInitStructure);//��ʼ��
	
  ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;//12λģʽ
  ADC_InitStructure.ADC_ScanConvMode = DISABLE;//��ɨ��ģʽ	
  ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;//�ر�����ת��
  ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_Rising;//��ֹ������⣬ʹ����������
	ADC_InitStructure.ADC_ExternalTrigConv= ADC_ExternalTrigConv_T3_CC1;
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;//�Ҷ���	
  ADC_InitStructure.ADC_NbrOfConversion = 1;//1��ת���ڹ��������� Ҳ����ֻת����������1 
  
	ADC_Init(ADC1, &ADC_InitStructure);//ADC��ʼ��
	ADC_Init(ADC2, &ADC_InitStructure);//ADC��ʼ��
	
  ADC_MultiModeDMARequestAfterLastTransferCmd(ENABLE);
	
	//ADC_ExternalTrigConvCmd(ADC1, ENABLE); 
	ADC_Cmd(ADC1, ENABLE);//����ADת����	
	ADC_Cmd(ADC2, ENABLE);//����ADת����	

}			
static void DMA_Config(void)
{
  DMA_InitTypeDef DMA_InitStructure;
	// here set the interrupt
	NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = DMA2_Stream0_IRQn;  //??????
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0; //??????
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;            //?????
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;       //????
    NVIC_Init(&NVIC_InitStructure); 
	
	
  DMA_InitStructure.DMA_Channel = DMA_Channel_0; 
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)&aADCDualConvertedValue;
  DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)ADC_CCR_ADDRESS;
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
  DMA_InitStructure.DMA_BufferSize = 2;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Enable;         
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;

DMA_Init(DMA2_Stream0, &DMA_InitStructure);

//DMA_ITConfig(DMA2_Stream0, DMA_IT_TC, ENABLE);    //??DMA??
DMA_ClearITPendingBit(DMA2_Stream0, DMA_IT_TC); //??????   
DMA_ITConfig(DMA2_Stream0, DMA_IT_TC, ENABLE); //?????? 
/* DMA2_Stream0 enable */
DMA_Cmd(DMA2_Stream0, ENABLE);
}

//https://blog.csdn.net/beytagh_/article/details/79555336
//https://zhidao.baidu.com/question/1365834701082429579.html
void DMA2_Stream0_IRQHandler(void) 
{     
	if(DMA_GetITStatus(DMA2_Stream0, DMA_IT_TCIF0))  //??DMA??????  
	{
		DMA_ClearITPendingBit(DMA2_Stream0, DMA_IT_TCIF0);
		
		printf("DMA interrupt:\r\n");
		adcVal01= aADCDualConvertedValue[0];			
		adcVal02= aADCDualConvertedValue[1];		
		sprintf(msgstr,"adc ch5=%d ch6=%d\r\n",adcVal01,adcVal02);
		printf(msgstr);
		printf("\r\n");
	}
}

