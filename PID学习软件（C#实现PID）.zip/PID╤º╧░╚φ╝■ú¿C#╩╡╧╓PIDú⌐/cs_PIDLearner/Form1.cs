﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Windows.Forms.DataVisualization.Charting;

namespace cs_PIDLearner
{
    public partial class Form1 : Form
    {
        Queue q = new Queue();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            buttonQSpid_Click(buttonQSpid, new EventArgs());
            button_NoiseSet_Click(button_NoiseSet, new EventArgs());
            button_PIDSet_Click(button_PIDStepSet, new EventArgs());

            for (int i = 0; i < 1000; i++)
            {
                q.Enqueue(0.0);
            }
            InitChart();
            timerData.Start();
            textBox_RefLevel.Text = trackBar_RefLevel.Value.ToString();
        }

        /// <summary>
        /// 初始化图表
        /// </summary>
        private void InitChart()
        {
            //定义图表区域
            this.chart1.ChartAreas.Clear();
            ChartArea chartArea1 = new ChartArea("C1");
            this.chart1.ChartAreas.Add(chartArea1);
            //定义存储和显示点的容器
            this.chart1.Series.Clear();
            Series series1 = new Series("Current");
            Series series2 = new Series("Reference");
            //series1.IsVisibleInLegend = false;
            //series1.ChartArea = "C1";
            this.chart1.Series.Add(series1);
            this.chart1.Series.Add(series2);
            //设置图表显示样式
            this.chart1.ChartAreas[0].AxisX.LabelStyle.Enabled = false;
            //this.chart1.ChartAreas[0].AxisY.LabelStyle.Enabled = false;
            this.chart1.ChartAreas[0].AxisY.Minimum = -200;
            this.chart1.ChartAreas[0].AxisY.Maximum = 200;
            this.chart1.ChartAreas[0].AxisY.Interval = 20;
            this.chart1.ChartAreas[0].AxisX.Interval = 100;
            this.chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = System.Drawing.Color.Silver;
            this.chart1.ChartAreas[0].AxisY.MajorGrid.LineColor = System.Drawing.Color.Silver;
            //设置标题
            //this.chart1.Titles.Clear();
            //this.chart1.Titles.Add("S01");
            //this.chart1.Titles[0].Text = "XXX显示";
            //this.chart1.Titles[0].ForeColor = Color.RoyalBlue;
            //this.chart1.Titles[0].Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            //设置图表显示样式
            this.chart1.Series[0].Color = Color.Green;
            this.chart1.Series[0].ChartType = SeriesChartType.Line;
            this.chart1.Series[0].Points.Clear();
            this.chart1.Series[1].Color = Color.Brown;
            this.chart1.Series[1].ChartType = SeriesChartType.Line;
            this.chart1.Series[1].Points.Clear();
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        double refVal = 0;
        double curVal = 100.0, error = 0, integral = 0,errorLast=0;
        double Kp, Ki, Kd;
        double Namp, Nshift;
        int Nstep, stepCnt = 0;


        private void resetArgs()
        {
            error = 0;
            integral = 0;
            errorLast = 0;
        }
        private void buttonDataReset_Click(object sender, EventArgs e)
        {
            curVal = 0;
            resetArgs();
        }

        int i = 0;
        private void timerData_Tick(object sender, EventArgs e)
        {
                curVal += rd.Next(0 - Convert.ToInt32(Namp / 2), Convert.ToInt32(Namp / 2) + 1) + Nshift;

                if (++stepCnt >= Nstep)
                {
                    errorLast = error;
                    // PID - Difference between curVal and refVal
                    error = curVal - refVal;
                    integral += error;
                    // PID
                    curVal = curVal + Kp * error + Ki * integral + Kd * (error - errorLast);
                    stepCnt = 0;
                }

                if (curVal > 99999 || curVal < -99999)
                {
                    timerData.Stop();
                    curVal = 0;
                    resetArgs();
                    textBox_PSet.Text = "-0.1";
                    textBox_ISet.Text = "-0.1";
                    textBox_DSet.Text = "-0.1";
                    textBox_NAmpSet.Text = "1";
                    textBox_NShiftSet.Text = "0";
                    buttonQSpid_Click(buttonQSpid, new EventArgs());
                    button_NoiseSet_Click(button_NoiseSet, new EventArgs());
                    button_PIDSet_Click(button_PIDStepSet, new EventArgs());
                    MessageBox.Show("计算值超出安全范围，可能是PID参数设置不合适，已设置为默认值。","警告");
                    timerData.Start();
                }
                textBoxMsg.Text =
                    "Current   = " + curVal.ToString("F5") + Environment.NewLine +
                    "Reference = " + refVal.ToString("F5") + Environment.NewLine +
                    "Error     = " + error.ToString("F5") + Environment.NewLine +
                    "Integral  = " + integral.ToString("F5") + Environment.NewLine +
                    "ErrorLast = " + errorLast.ToString("F5") + Environment.NewLine +
                    "Namp      = " + Namp.ToString("F5") + Environment.NewLine +
                    "Nshift    = " + Nshift.ToString("F5") + Environment.NewLine +
                    "";

                q.Enqueue(Convert.ToDouble(curVal));
                q.Dequeue();

                this.chart1.Series[1].Points.Clear();
                for (i = 0; i < 1000; i++)
                {
                    this.chart1.Series[1].Points.AddXY(i, refVal);
                }

                this.chart1.Series[0].Points.Clear();
                i = 0;
                foreach (double c in q)
                {
                    this.chart1.Series[0].Points.AddXY(i, c);
                    i++;
                }
        }
        
        private void trackBar_RefLevel_Scroll(object sender, EventArgs e)
        {
            refVal = trackBar_RefLevel.Value;
            textBox_RefLevel.Text = refVal.ToString();
        }

        private void button_RefLevelSet_Click(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToDouble(textBox_RefLevelSet.Text) < -100)
                {
                    textBox_RefLevel.Text = "-100";
                }
                else if (Convert.ToDouble(textBox_RefLevelSet.Text) > 100)
                {
                    textBox_RefLevel.Text = "100";
                }
                else
                {
                    textBox_RefLevel.Text = textBox_RefLevelSet.Text;
                }
                refVal = Convert.ToDouble(textBox_RefLevel.Text);
            }
            catch
            {
                refVal = 0;
            }
            trackBar_RefLevel.Value = (int)refVal;
        }

        private void button_NoiseSet_Click(object sender, EventArgs e)
        {
            resetArgs();

            try
            {
                if (Convert.ToDouble(textBox_NAmpSet.Text) < 0)
                {
                    textBox_NAmp.Text = "0";
                }
                else if (Convert.ToDouble(textBox_NAmpSet.Text) > 200)
                {
                    textBox_NAmp.Text = "200";
                }
                else
                {
                    textBox_NAmp.Text = textBox_NAmpSet.Text;
                }
            }
            catch
            {
                textBox_NAmp.Text = "1";
            }
            Namp = Convert.ToDouble(textBox_NAmp.Text);

            try
            {
                if (Convert.ToDouble(textBox_NShiftSet.Text) < -100)
                {
                    textBox_NShift.Text = "-100";
                }
                else if (Convert.ToDouble(textBox_NShiftSet.Text) > 100)
                {
                    textBox_NShift.Text = "100";
                }
                else
                {
                    textBox_NShift.Text = textBox_NShiftSet.Text;
                }
            }
            catch
            {
                textBox_NShift.Text = "0";
            }
            Nshift = Convert.ToDouble(textBox_NShift.Text);
        }
        Random rd = new Random();
        private void button_NoiseRandom_Click(object sender, EventArgs e)
        {
            resetArgs();

            Namp = rd.Next(0,10);
            textBox_NAmp.Text = Namp.ToString();
        }

        private void button_NoiseNo_Click(object sender, EventArgs e)
        {
            resetArgs();

            Namp = 0;
            textBox_NAmp.Text = Namp.ToString();
            Nshift = 0;
            textBox_NShift.Text = Nshift.ToString();
        }

        private void button_PIDSet_Click(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToInt32(textBox_PIDStepSet.Text) < 1)
                {
                    textBox_PIDStep.Text = "1";
                }
                else if (Convert.ToInt32(textBox_PIDStepSet.Text) > 100)
                {
                    textBox_PIDStep.Text = "100";
                }
                else
                {
                    textBox_PIDStep.Text = textBox_PIDStepSet.Text;
                }
            }
            catch
            {
                textBox_PIDStep.Text = "4";
            }
            Nstep = Convert.ToInt32(textBox_PIDStep.Text);
        }

        private void buttonRun_Click(object sender, EventArgs e)
        {
            if ("▶"==buttonRun.Text )
            {
                buttonRun.Text = "||";
                timerData.Start();
            }
            else
            {
                buttonRun.Text = "▶";
                timerData.Stop();
            }
        }

        private void textBox_RefLevelSet_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_RefLevel_TextChanged(object sender, EventArgs e)
        {

        }
        
        private void setPIDp()
        {
            try
            {
                if (Convert.ToDouble(textBox_PSet.Text) < -10)
                {
                    textBox_P.Text = "-10";
                }
                else if (Convert.ToDouble(textBox_PSet.Text) > 10)
                {
                    textBox_P.Text = "10";
                }
                else
                {
                    textBox_P.Text = textBox_PSet.Text;
                }
            }
            catch
            {
                textBox_P.Text = "-0.1";
            }
            Kp = Convert.ToDouble(textBox_P.Text);
        }
        private void setPIDi()
        {
            try
            {
                if (Convert.ToDouble(textBox_ISet.Text) < -10)
                {
                    textBox_I.Text = "-10";
                }
                else if (Convert.ToDouble(textBox_ISet.Text) > 10)
                {
                    textBox_I.Text = "10";
                }
                else
                {
                    textBox_I.Text = textBox_ISet.Text;
                }
            }
            catch
            {
                textBox_I.Text = "-0.1";
            }
            Ki = Convert.ToDouble(textBox_I.Text);
        }
        private void setPIDd()
        {
            try
            {
                if (Convert.ToDouble(textBox_DSet.Text) < -100)
                {
                    textBox_D.Text = "-10";
                }
                else if (Convert.ToDouble(textBox_DSet.Text) > 100)
                {
                    textBox_D.Text = "10";
                }
                else
                {
                    textBox_D.Text = textBox_DSet.Text;
                }
            }
            catch
            {
                textBox_D.Text = "-0.1";
            }
            Kd = Convert.ToDouble(textBox_D.Text);
        }

        private void buttonQSp_Click(object sender, EventArgs e)
        {
            buttonQSp.BackColor = Color.Yellow;
            buttonQSi.BackColor = Color.Gainsboro;
            buttonQSd.BackColor = Color.Gainsboro;
            buttonQSpi.BackColor = Color.Gainsboro;
            buttonQSpd.BackColor = Color.Gainsboro;
            buttonQSpid.BackColor = Color.Gainsboro;
            buttonQSnone.BackColor = Color.Gainsboro;

            resetArgs();

            setPIDp();

            textBox_I.Text = "0";
            Ki = Convert.ToDouble(textBox_I.Text);
            textBox_D.Text = "0";
            Kd = Convert.ToDouble(textBox_D.Text);
        }

        private void buttonQSi_Click(object sender, EventArgs e)
        {
            buttonQSp.BackColor = Color.Gainsboro;
            buttonQSi.BackColor = Color.Yellow;
            buttonQSd.BackColor = Color.Gainsboro;
            buttonQSpi.BackColor = Color.Gainsboro;
            buttonQSpd.BackColor = Color.Gainsboro;
            buttonQSpid.BackColor = Color.Gainsboro;
            buttonQSnone.BackColor = Color.Gainsboro;

            resetArgs();

            setPIDi();

            textBox_P.Text = "0";
            Kp = Convert.ToDouble(textBox_P.Text);
            textBox_D.Text = "0";
            Kd = Convert.ToDouble(textBox_D.Text);

        }

        private void buttonQSd_Click(object sender, EventArgs e)
        {
            buttonQSp.BackColor = Color.Gainsboro;
            buttonQSi.BackColor = Color.Gainsboro;
            buttonQSd.BackColor = Color.Yellow;
            buttonQSpi.BackColor = Color.Gainsboro;
            buttonQSpd.BackColor = Color.Gainsboro;
            buttonQSpid.BackColor = Color.Gainsboro;
            buttonQSnone.BackColor = Color.Gainsboro;

            resetArgs();

            setPIDd();

            textBox_P.Text = "0";
            Kp = Convert.ToDouble(textBox_P.Text);
            textBox_I.Text = "0";
            Ki = Convert.ToDouble(textBox_I.Text);
        }

        private void buttonQSpid_Click(object sender, EventArgs e)
        {
            buttonQSp.BackColor = Color.Gainsboro;
            buttonQSi.BackColor = Color.Gainsboro;
            buttonQSd.BackColor = Color.Gainsboro;
            buttonQSpi.BackColor = Color.Gainsboro;
            buttonQSpd.BackColor = Color.Gainsboro;
            buttonQSpid.BackColor = Color.Yellow;
            buttonQSnone.BackColor = Color.Gainsboro;

            resetArgs();

            setPIDp();
            setPIDi();
            setPIDd();
        }

        private void buttonQSpi_Click(object sender, EventArgs e)
        {
            buttonQSp.BackColor = Color.Gainsboro;
            buttonQSi.BackColor = Color.Gainsboro;
            buttonQSd.BackColor = Color.Gainsboro;
            buttonQSpi.BackColor = Color.Yellow;
            buttonQSpd.BackColor = Color.Gainsboro;
            buttonQSpid.BackColor = Color.Gainsboro;
            buttonQSnone.BackColor = Color.Gainsboro;

            resetArgs();

            setPIDp();
            setPIDi();

            textBox_D.Text = "0";
            Kd = Convert.ToDouble(textBox_D.Text);
        }

        private void buttonQSpd_Click(object sender, EventArgs e)
        {
            buttonQSp.BackColor = Color.Gainsboro;
            buttonQSi.BackColor = Color.Gainsboro;
            buttonQSd.BackColor = Color.Gainsboro;
            buttonQSpi.BackColor = Color.Gainsboro;
            buttonQSpd.BackColor = Color.Yellow;
            buttonQSpid.BackColor = Color.Gainsboro;
            buttonQSnone.BackColor = Color.Gainsboro;

            resetArgs();

            setPIDp();
            setPIDd();

            textBox_I.Text = "0";
            Ki = Convert.ToDouble(textBox_I.Text);
        }

        private void buttonQSnone_Click(object sender, EventArgs e)
        {
            buttonQSp.BackColor = Color.Gainsboro;
            buttonQSi.BackColor = Color.Gainsboro;
            buttonQSd.BackColor = Color.Gainsboro;
            buttonQSpi.BackColor = Color.Gainsboro;
            buttonQSpd.BackColor = Color.Gainsboro;
            buttonQSpid.BackColor = Color.Gainsboro;
            buttonQSnone.BackColor = Color.Yellow;

            resetArgs();

            textBox_P.Text = "0";
            Kp = Convert.ToDouble(textBox_P.Text);
            textBox_I.Text = "0";
            Ki = Convert.ToDouble(textBox_I.Text);
            textBox_D.Text = "0";
            Kd = Convert.ToDouble(textBox_D.Text);
        }
    }
}
