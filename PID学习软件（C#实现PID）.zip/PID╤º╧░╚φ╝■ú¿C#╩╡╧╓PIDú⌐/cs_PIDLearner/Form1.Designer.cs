﻿namespace cs_PIDLearner
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_PSet = new System.Windows.Forms.TextBox();
            this.textBox_ISet = new System.Windows.Forms.TextBox();
            this.textBox_DSet = new System.Windows.Forms.TextBox();
            this.button_PIDStepSet = new System.Windows.Forms.Button();
            this.button_NoiseNo = new System.Windows.Forms.Button();
            this.textBox_P = new System.Windows.Forms.TextBox();
            this.textBox_I = new System.Windows.Forms.TextBox();
            this.textBox_D = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_NAmp = new System.Windows.Forms.TextBox();
            this.textBox_PIDStep = new System.Windows.Forms.TextBox();
            this.textBox_PIDStepSet = new System.Windows.Forms.TextBox();
            this.textBox_NAmpSet = new System.Windows.Forms.TextBox();
            this.button_NoiseRandom = new System.Windows.Forms.Button();
            this.button_NoiseSet = new System.Windows.Forms.Button();
            this.trackBar_RefLevel = new System.Windows.Forms.TrackBar();
            this.textBox_RefLevel = new System.Windows.Forms.TextBox();
            this.button_RefLevelSet = new System.Windows.Forms.Button();
            this.timerData = new System.Windows.Forms.Timer(this.components);
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.textBox_RefLevelSet = new System.Windows.Forms.TextBox();
            this.buttonDataReset = new System.Windows.Forms.Button();
            this.textBoxMsg = new System.Windows.Forms.TextBox();
            this.buttonRun = new System.Windows.Forms.Button();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.buttonQSp = new System.Windows.Forms.Button();
            this.buttonQSpi = new System.Windows.Forms.Button();
            this.buttonQSpd = new System.Windows.Forms.Button();
            this.buttonQSpid = new System.Windows.Forms.Button();
            this.buttonQSi = new System.Windows.Forms.Button();
            this.buttonQSd = new System.Windows.Forms.Button();
            this.buttonQSnone = new System.Windows.Forms.Button();
            this.textBox_NShiftSet = new System.Windows.Forms.TextBox();
            this.textBox_NShift = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_RefLevel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(668, 331);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "P (-10~10) =";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(668, 357);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "I (-10~10) =";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(668, 384);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 12);
            this.label3.TabIndex = 3;
            this.label3.Text = "D (-10~10) =";
            // 
            // textBox_PSet
            // 
            this.textBox_PSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_PSet.Location = new System.Drawing.Point(824, 327);
            this.textBox_PSet.Name = "textBox_PSet";
            this.textBox_PSet.Size = new System.Drawing.Size(67, 21);
            this.textBox_PSet.TabIndex = 4;
            this.textBox_PSet.Text = "-0.1";
            this.textBox_PSet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox_ISet
            // 
            this.textBox_ISet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_ISet.Location = new System.Drawing.Point(824, 354);
            this.textBox_ISet.Name = "textBox_ISet";
            this.textBox_ISet.Size = new System.Drawing.Size(67, 21);
            this.textBox_ISet.TabIndex = 5;
            this.textBox_ISet.Text = "-0.1";
            this.textBox_ISet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox_DSet
            // 
            this.textBox_DSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_DSet.Location = new System.Drawing.Point(824, 381);
            this.textBox_DSet.Name = "textBox_DSet";
            this.textBox_DSet.Size = new System.Drawing.Size(67, 21);
            this.textBox_DSet.TabIndex = 6;
            this.textBox_DSet.Text = "-0.1";
            this.textBox_DSet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // button_PIDStepSet
            // 
            this.button_PIDStepSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_PIDStepSet.Location = new System.Drawing.Point(897, 408);
            this.button_PIDStepSet.Name = "button_PIDStepSet";
            this.button_PIDStepSet.Size = new System.Drawing.Size(96, 22);
            this.button_PIDStepSet.TabIndex = 7;
            this.button_PIDStepSet.Text = "Set Span";
            this.button_PIDStepSet.UseVisualStyleBackColor = true;
            this.button_PIDStepSet.Click += new System.EventHandler(this.button_PIDSet_Click);
            // 
            // button_NoiseNo
            // 
            this.button_NoiseNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_NoiseNo.Location = new System.Drawing.Point(192, 410);
            this.button_NoiseNo.Name = "button_NoiseNo";
            this.button_NoiseNo.Size = new System.Drawing.Size(111, 22);
            this.button_NoiseNo.TabIndex = 14;
            this.button_NoiseNo.Text = "No Noise";
            this.button_NoiseNo.UseVisualStyleBackColor = true;
            this.button_NoiseNo.Click += new System.EventHandler(this.button_NoiseNo_Click);
            // 
            // textBox_P
            // 
            this.textBox_P.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_P.Enabled = false;
            this.textBox_P.Location = new System.Drawing.Point(751, 327);
            this.textBox_P.Name = "textBox_P";
            this.textBox_P.Size = new System.Drawing.Size(67, 21);
            this.textBox_P.TabIndex = 13;
            this.textBox_P.Text = "0";
            this.textBox_P.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox_I
            // 
            this.textBox_I.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_I.Enabled = false;
            this.textBox_I.Location = new System.Drawing.Point(751, 354);
            this.textBox_I.Name = "textBox_I";
            this.textBox_I.Size = new System.Drawing.Size(67, 21);
            this.textBox_I.TabIndex = 12;
            this.textBox_I.Text = "0";
            this.textBox_I.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox_D
            // 
            this.textBox_D.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_D.Enabled = false;
            this.textBox_D.Location = new System.Drawing.Point(751, 381);
            this.textBox_D.Name = "textBox_D";
            this.textBox_D.Size = new System.Drawing.Size(67, 21);
            this.textBox_D.TabIndex = 11;
            this.textBox_D.Text = "0";
            this.textBox_D.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(662, 412);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 12);
            this.label5.TabIndex = 9;
            this.label5.Text = "Span(1~100) =";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(190, 334);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 12);
            this.label6.TabIndex = 8;
            this.label6.Text = "Noise Amp(0~200) =";
            // 
            // textBox_NAmp
            // 
            this.textBox_NAmp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_NAmp.Enabled = false;
            this.textBox_NAmp.Location = new System.Drawing.Point(309, 331);
            this.textBox_NAmp.Name = "textBox_NAmp";
            this.textBox_NAmp.Size = new System.Drawing.Size(52, 21);
            this.textBox_NAmp.TabIndex = 20;
            this.textBox_NAmp.Text = "0";
            this.textBox_NAmp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox_PIDStep
            // 
            this.textBox_PIDStep.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_PIDStep.Enabled = false;
            this.textBox_PIDStep.Location = new System.Drawing.Point(751, 409);
            this.textBox_PIDStep.Name = "textBox_PIDStep";
            this.textBox_PIDStep.Size = new System.Drawing.Size(67, 21);
            this.textBox_PIDStep.TabIndex = 19;
            this.textBox_PIDStep.Text = "1";
            this.textBox_PIDStep.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox_PIDStepSet
            // 
            this.textBox_PIDStepSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_PIDStepSet.Location = new System.Drawing.Point(824, 409);
            this.textBox_PIDStepSet.Name = "textBox_PIDStepSet";
            this.textBox_PIDStepSet.Size = new System.Drawing.Size(67, 21);
            this.textBox_PIDStepSet.TabIndex = 16;
            this.textBox_PIDStepSet.Text = "4";
            this.textBox_PIDStepSet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox_NAmpSet
            // 
            this.textBox_NAmpSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_NAmpSet.Location = new System.Drawing.Point(367, 331);
            this.textBox_NAmpSet.Name = "textBox_NAmpSet";
            this.textBox_NAmpSet.Size = new System.Drawing.Size(52, 21);
            this.textBox_NAmpSet.TabIndex = 15;
            this.textBox_NAmpSet.Text = "1";
            this.textBox_NAmpSet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // button_NoiseRandom
            // 
            this.button_NoiseRandom.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_NoiseRandom.Location = new System.Drawing.Point(192, 386);
            this.button_NoiseRandom.Name = "button_NoiseRandom";
            this.button_NoiseRandom.Size = new System.Drawing.Size(111, 21);
            this.button_NoiseRandom.TabIndex = 21;
            this.button_NoiseRandom.Text = "Random Noise";
            this.button_NoiseRandom.UseVisualStyleBackColor = true;
            this.button_NoiseRandom.Click += new System.EventHandler(this.button_NoiseRandom_Click);
            // 
            // button_NoiseSet
            // 
            this.button_NoiseSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_NoiseSet.Location = new System.Drawing.Point(309, 385);
            this.button_NoiseSet.Name = "button_NoiseSet";
            this.button_NoiseSet.Size = new System.Drawing.Size(110, 48);
            this.button_NoiseSet.TabIndex = 22;
            this.button_NoiseSet.Text = "Set Noise";
            this.button_NoiseSet.UseVisualStyleBackColor = true;
            this.button_NoiseSet.Click += new System.EventHandler(this.button_NoiseSet_Click);
            // 
            // trackBar_RefLevel
            // 
            this.trackBar_RefLevel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.trackBar_RefLevel.BackColor = System.Drawing.Color.White;
            this.trackBar_RefLevel.Location = new System.Drawing.Point(858, 191);
            this.trackBar_RefLevel.Maximum = 100;
            this.trackBar_RefLevel.Minimum = -100;
            this.trackBar_RefLevel.Name = "trackBar_RefLevel";
            this.trackBar_RefLevel.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar_RefLevel.Size = new System.Drawing.Size(45, 101);
            this.trackBar_RefLevel.TabIndex = 1;
            this.trackBar_RefLevel.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.trackBar_RefLevel.Scroll += new System.EventHandler(this.trackBar_RefLevel_Scroll);
            // 
            // textBox_RefLevel
            // 
            this.textBox_RefLevel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_RefLevel.Enabled = false;
            this.textBox_RefLevel.Location = new System.Drawing.Point(909, 191);
            this.textBox_RefLevel.Name = "textBox_RefLevel";
            this.textBox_RefLevel.Size = new System.Drawing.Size(71, 21);
            this.textBox_RefLevel.TabIndex = 24;
            this.textBox_RefLevel.Text = "0";
            this.textBox_RefLevel.TextChanged += new System.EventHandler(this.textBox_RefLevel_TextChanged);
            // 
            // button_RefLevelSet
            // 
            this.button_RefLevelSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_RefLevelSet.Location = new System.Drawing.Point(909, 245);
            this.button_RefLevelSet.Name = "button_RefLevelSet";
            this.button_RefLevelSet.Size = new System.Drawing.Size(71, 47);
            this.button_RefLevelSet.TabIndex = 25;
            this.button_RefLevelSet.Text = "Set Ref";
            this.button_RefLevelSet.UseVisualStyleBackColor = true;
            this.button_RefLevelSet.Click += new System.EventHandler(this.button_RefLevelSet_Click);
            // 
            // timerData
            // 
            this.timerData.Interval = 10;
            this.timerData.Tick += new System.EventHandler(this.timerData_Tick);
            // 
            // chart1
            // 
            this.chart1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(12, 12);
            this.chart1.Name = "chart1";
            this.chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Grayscale;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(984, 300);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            this.chart1.Click += new System.EventHandler(this.chart1_Click);
            // 
            // textBox_RefLevelSet
            // 
            this.textBox_RefLevelSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_RefLevelSet.Location = new System.Drawing.Point(909, 218);
            this.textBox_RefLevelSet.Name = "textBox_RefLevelSet";
            this.textBox_RefLevelSet.Size = new System.Drawing.Size(71, 21);
            this.textBox_RefLevelSet.TabIndex = 26;
            this.textBox_RefLevelSet.Text = "0";
            this.textBox_RefLevelSet.TextChanged += new System.EventHandler(this.textBox_RefLevelSet_TextChanged);
            // 
            // buttonDataReset
            // 
            this.buttonDataReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonDataReset.Location = new System.Drawing.Point(444, 412);
            this.buttonDataReset.Name = "buttonDataReset";
            this.buttonDataReset.Size = new System.Drawing.Size(194, 21);
            this.buttonDataReset.TabIndex = 27;
            this.buttonDataReset.Text = "Reset All System Data to \"0\"";
            this.buttonDataReset.UseVisualStyleBackColor = true;
            this.buttonDataReset.Click += new System.EventHandler(this.buttonDataReset_Click);
            // 
            // textBoxMsg
            // 
            this.textBoxMsg.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxMsg.Enabled = false;
            this.textBoxMsg.Font = new System.Drawing.Font("SimSun", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBoxMsg.Location = new System.Drawing.Point(444, 327);
            this.textBoxMsg.Multiline = true;
            this.textBoxMsg.Name = "textBoxMsg";
            this.textBoxMsg.Size = new System.Drawing.Size(194, 78);
            this.textBoxMsg.TabIndex = 28;
            // 
            // buttonRun
            // 
            this.buttonRun.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonRun.Font = new System.Drawing.Font("Microsoft YaHei", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonRun.Location = new System.Drawing.Point(799, 34);
            this.buttonRun.Name = "buttonRun";
            this.buttonRun.Size = new System.Drawing.Size(20, 20);
            this.buttonRun.TabIndex = 29;
            this.buttonRun.Text = "||";
            this.buttonRun.UseVisualStyleBackColor = true;
            this.buttonRun.Click += new System.EventHandler(this.buttonRun_Click);
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape2,
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(1008, 441);
            this.shapeContainer1.TabIndex = 30;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape2
            // 
            this.lineShape2.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 650;
            this.lineShape2.X2 = 650;
            this.lineShape2.Y1 = 324;
            this.lineShape2.Y2 = 436;
            // 
            // lineShape1
            // 
            this.lineShape1.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 431;
            this.lineShape1.X2 = 431;
            this.lineShape1.Y1 = 324;
            this.lineShape1.Y2 = 436;
            // 
            // buttonQSp
            // 
            this.buttonQSp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonQSp.Location = new System.Drawing.Point(897, 326);
            this.buttonQSp.Name = "buttonQSp";
            this.buttonQSp.Size = new System.Drawing.Size(28, 23);
            this.buttonQSp.TabIndex = 31;
            this.buttonQSp.Text = "P";
            this.buttonQSp.UseVisualStyleBackColor = true;
            this.buttonQSp.Click += new System.EventHandler(this.buttonQSp_Click);
            // 
            // buttonQSpi
            // 
            this.buttonQSpi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonQSpi.Location = new System.Drawing.Point(897, 353);
            this.buttonQSpi.Name = "buttonQSpi";
            this.buttonQSpi.Size = new System.Drawing.Size(45, 23);
            this.buttonQSpi.TabIndex = 33;
            this.buttonQSpi.Text = "PI";
            this.buttonQSpi.UseVisualStyleBackColor = true;
            this.buttonQSpi.Click += new System.EventHandler(this.buttonQSpi_Click);
            // 
            // buttonQSpd
            // 
            this.buttonQSpd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonQSpd.Location = new System.Drawing.Point(948, 352);
            this.buttonQSpd.Name = "buttonQSpd";
            this.buttonQSpd.Size = new System.Drawing.Size(45, 23);
            this.buttonQSpd.TabIndex = 34;
            this.buttonQSpd.Text = "PD";
            this.buttonQSpd.UseVisualStyleBackColor = true;
            this.buttonQSpd.Click += new System.EventHandler(this.buttonQSpd_Click);
            // 
            // buttonQSpid
            // 
            this.buttonQSpid.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonQSpid.Location = new System.Drawing.Point(897, 379);
            this.buttonQSpid.Name = "buttonQSpid";
            this.buttonQSpid.Size = new System.Drawing.Size(45, 23);
            this.buttonQSpid.TabIndex = 35;
            this.buttonQSpid.Text = "PID";
            this.buttonQSpid.UseVisualStyleBackColor = true;
            this.buttonQSpid.Click += new System.EventHandler(this.buttonQSpid_Click);
            // 
            // buttonQSi
            // 
            this.buttonQSi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonQSi.Location = new System.Drawing.Point(931, 326);
            this.buttonQSi.Name = "buttonQSi";
            this.buttonQSi.Size = new System.Drawing.Size(28, 23);
            this.buttonQSi.TabIndex = 36;
            this.buttonQSi.Text = "I";
            this.buttonQSi.UseVisualStyleBackColor = true;
            this.buttonQSi.Click += new System.EventHandler(this.buttonQSi_Click);
            // 
            // buttonQSd
            // 
            this.buttonQSd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonQSd.Location = new System.Drawing.Point(965, 326);
            this.buttonQSd.Name = "buttonQSd";
            this.buttonQSd.Size = new System.Drawing.Size(28, 23);
            this.buttonQSd.TabIndex = 37;
            this.buttonQSd.Text = "D";
            this.buttonQSd.UseVisualStyleBackColor = true;
            this.buttonQSd.Click += new System.EventHandler(this.buttonQSd_Click);
            // 
            // buttonQSnone
            // 
            this.buttonQSnone.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonQSnone.BackColor = System.Drawing.Color.Gainsboro;
            this.buttonQSnone.Location = new System.Drawing.Point(948, 379);
            this.buttonQSnone.Name = "buttonQSnone";
            this.buttonQSnone.Size = new System.Drawing.Size(45, 23);
            this.buttonQSnone.TabIndex = 38;
            this.buttonQSnone.Text = "None";
            this.buttonQSnone.UseVisualStyleBackColor = false;
            this.buttonQSnone.Click += new System.EventHandler(this.buttonQSnone_Click);
            // 
            // textBox_NShiftSet
            // 
            this.textBox_NShiftSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_NShiftSet.Location = new System.Drawing.Point(367, 358);
            this.textBox_NShiftSet.Name = "textBox_NShiftSet";
            this.textBox_NShiftSet.Size = new System.Drawing.Size(52, 21);
            this.textBox_NShiftSet.TabIndex = 17;
            this.textBox_NShiftSet.Text = "0";
            this.textBox_NShiftSet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox_NShift
            // 
            this.textBox_NShift.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_NShift.Enabled = false;
            this.textBox_NShift.Location = new System.Drawing.Point(309, 358);
            this.textBox_NShift.Name = "textBox_NShift";
            this.textBox_NShift.Size = new System.Drawing.Size(52, 21);
            this.textBox_NShift.TabIndex = 18;
            this.textBox_NShift.Text = "0";
            this.textBox_NShift.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(160, 361);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(143, 12);
            this.label4.TabIndex = 10;
            this.label4.Text = "Noise Shift(-100~100) =";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1008, 441);
            this.Controls.Add(this.buttonQSnone);
            this.Controls.Add(this.buttonQSd);
            this.Controls.Add(this.buttonQSi);
            this.Controls.Add(this.buttonQSpid);
            this.Controls.Add(this.buttonQSpd);
            this.Controls.Add(this.buttonQSpi);
            this.Controls.Add(this.buttonQSp);
            this.Controls.Add(this.buttonRun);
            this.Controls.Add(this.textBoxMsg);
            this.Controls.Add(this.buttonDataReset);
            this.Controls.Add(this.textBox_RefLevelSet);
            this.Controls.Add(this.button_RefLevelSet);
            this.Controls.Add(this.textBox_RefLevel);
            this.Controls.Add(this.trackBar_RefLevel);
            this.Controls.Add(this.button_NoiseSet);
            this.Controls.Add(this.button_NoiseRandom);
            this.Controls.Add(this.textBox_NAmp);
            this.Controls.Add(this.textBox_PIDStep);
            this.Controls.Add(this.textBox_NShift);
            this.Controls.Add(this.textBox_NShiftSet);
            this.Controls.Add(this.textBox_PIDStepSet);
            this.Controls.Add(this.textBox_NAmpSet);
            this.Controls.Add(this.button_NoiseNo);
            this.Controls.Add(this.textBox_P);
            this.Controls.Add(this.textBox_I);
            this.Controls.Add(this.textBox_D);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button_PIDStepSet);
            this.Controls.Add(this.textBox_DSet);
            this.Controls.Add(this.textBox_ISet);
            this.Controls.Add(this.textBox_PSet);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.shapeContainer1);
            this.MinimumSize = new System.Drawing.Size(1024, 480);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PID Learner （jinkai1992@mail.ccnu.edu.cn）";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_RefLevel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_PSet;
        private System.Windows.Forms.TextBox textBox_ISet;
        private System.Windows.Forms.TextBox textBox_DSet;
        private System.Windows.Forms.Button button_PIDStepSet;
        private System.Windows.Forms.Button button_NoiseNo;
        private System.Windows.Forms.TextBox textBox_P;
        private System.Windows.Forms.TextBox textBox_I;
        private System.Windows.Forms.TextBox textBox_D;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_NAmp;
        private System.Windows.Forms.TextBox textBox_PIDStep;
        private System.Windows.Forms.TextBox textBox_PIDStepSet;
        private System.Windows.Forms.TextBox textBox_NAmpSet;
        private System.Windows.Forms.Button button_NoiseRandom;
        private System.Windows.Forms.Button button_NoiseSet;
        private System.Windows.Forms.TrackBar trackBar_RefLevel;
        private System.Windows.Forms.TextBox textBox_RefLevel;
        private System.Windows.Forms.Button button_RefLevelSet;
        private System.Windows.Forms.Timer timerData;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.TextBox textBox_RefLevelSet;
        private System.Windows.Forms.Button buttonDataReset;
        private System.Windows.Forms.TextBox textBoxMsg;
        private System.Windows.Forms.Button buttonRun;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private System.Windows.Forms.Button buttonQSp;
        private System.Windows.Forms.Button buttonQSpi;
        private System.Windows.Forms.Button buttonQSpd;
        private System.Windows.Forms.Button buttonQSpid;
        private System.Windows.Forms.Button buttonQSi;
        private System.Windows.Forms.Button buttonQSd;
        private System.Windows.Forms.Button buttonQSnone;
        private System.Windows.Forms.TextBox textBox_NShiftSet;
        private System.Windows.Forms.TextBox textBox_NShift;
        private System.Windows.Forms.Label label4;
    }
}

